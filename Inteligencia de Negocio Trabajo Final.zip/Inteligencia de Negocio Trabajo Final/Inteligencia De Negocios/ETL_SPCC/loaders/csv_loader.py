"""
Modulo de carga de datos en formato CSV.
"""

import pandas as pd
import os
from loguru import logger
from config import settings


def save_to_csv(df: pd.DataFrame, filename: str, output_dir: str = None) -> str:
    """
    Guarda DataFrame a archivo CSV.
    
    Args:
        df: DataFrame a guardar
        filename: Nombre del archivo (sin extension)
        output_dir: Directorio de salida (por defecto usa settings.DATA_OUTPUT_DIR)
        
    Returns:
        Path completo del archivo guardado
    """
    if output_dir is None:
        output_dir = settings.DATA_OUTPUT_DIR
    
    # Asegurar que el directorio existe
    os.makedirs(output_dir, exist_ok=True)
    
    # Construir path completo
    if not filename.endswith('.csv'):
        filename = f"{filename}.csv"
    
    filepath = os.path.join(output_dir, filename)
    
    try:
        # Guardar CSV con encoding UTF-8-sig para compatibilidad Excel
        df.to_csv(filepath, index=False, encoding='utf-8-sig')
        
        logger.info(f"CSV guardado: {filepath} ({len(df)} registros, {len(df.columns)} columnas)")
        
        # Verificar que el archivo se creo
        if os.path.exists(filepath):
            file_size = os.path.getsize(filepath)
            logger.debug(f"Tamaño del archivo: {file_size:,} bytes")
        else:
            logger.error(f"Archivo no se creo: {filepath}")
            
        return filepath
        
    except Exception as e:
        logger.error(f"Error al guardar CSV {filename}: {e}")
        raise


def save_multiple_csv(datasets: dict, output_dir: str = None) -> dict:
    """
    Guarda multiples DataFrames a CSV.
    
    Args:
        datasets: Diccionario {nombre_archivo: DataFrame}
        output_dir: Directorio de salida
        
    Returns:
        Diccionario {nombre_archivo: filepath}
    """
    logger.info(f"Guardando {len(datasets)} archivos CSV...")
    
    saved_files = {}
    
    for filename, df in datasets.items():
        try:
            filepath = save_to_csv(df, filename, output_dir)
            saved_files[filename] = filepath
        except Exception as e:
            logger.error(f"Error guardando {filename}: {e}")
            saved_files[filename] = None
    
    successful = sum(1 for v in saved_files.values() if v is not None)
    logger.info(f"Archivos CSV guardados exitosamente: {successful}/{len(datasets)}")
    
    return saved_files


def validate_csv_output(filepath: str) -> bool:
    """
    Valida que un archivo CSV se guardo correctamente.
    
    Args:
        filepath: Path del archivo CSV
        
    Returns:
        True si el archivo es valido, False en caso contrario
    """
    try:
        if not os.path.exists(filepath):
            logger.error(f"Archivo no existe: {filepath}")
            return False
        
        # Intentar leer el archivo
        df = pd.read_csv(filepath, encoding='utf-8-sig')
        
        if len(df) == 0:
            logger.warning(f"Archivo CSV vacio: {filepath}")
            return False
        
        logger.debug(f"CSV validado: {filepath} ({len(df)} registros)")
        return True
        
    except Exception as e:
        logger.error(f"Error validando CSV {filepath}: {e}")
        return False
