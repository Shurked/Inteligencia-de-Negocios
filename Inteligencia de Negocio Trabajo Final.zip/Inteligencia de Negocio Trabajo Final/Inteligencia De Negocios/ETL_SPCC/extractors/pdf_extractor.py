"""
Extractor de datos de empleo y competencia (PDFs/Reportes simulados).
"""
import pandas as pd
import numpy as np
from loguru import logger
from config import settings
from utils import date_utils

def generate_employment_data() -> pd.DataFrame:
    logger.info("Generando datos de empleo...")
    quarters = date_utils.generate_quarters(2022, 2025)
    data = []
    base_data = {
        'Toquepala': {'tipo': 'Mina', 'cap': 220, 'dir': 2800, 'cont': 3200, 'oro': 0, 'acido': 0},
        'Cuajone': {'tipo': 'Mina', 'cap': 180, 'dir': 2200, 'cont': 2600, 'oro': 0, 'acido': 0},
        'Fundicion Ilo': {'tipo': 'Fundicion', 'cap': 300, 'dir': 1200, 'cont': 800, 'oro': 100, 'acido': 45000}
    }
    for year, quarter in quarters:
        ysb = year - 2022
        growth = 1 + (ysb * 0.03)
        for unidad, info in base_data.items():
            np.random.seed(hash(f"{year}{quarter}{unidad}") % 2**32)
            ed = int(info['dir'] * growth * np.random.uniform(0.98, 1.02))
            ec = int(info['cont'] * growth * np.random.uniform(0.95, 1.05))
            te = ed + ec
            h = int(te * 90 * 12 * np.random.uniform(0.95, 1.00))
            acc = int(np.random.poisson(1.5))
            cd = info['cap']
            util = np.random.uniform(85, 98)
            if info['tipo'] == 'Mina':
                pc = cd * 90 * (util / 100)
                pm, pp, pz, po, pa = pc * 0.03, pc * 0.2, 0, 0, 0
            else:
                pc, pm, pp, pz = 0, 0, 0, 0
                po = info['oro'] * np.random.uniform(0.95, 1.05)
                pa = info['acido'] * np.random.uniform(0.98, 1.02)
            cb = 80 if year >= 2024 and unidad == 'Toquepala' else 60 if year >= 2024 and unidad == 'Cuajone' else 30 if year >= 2024 else 50 if unidad == 'Toquepala' else 40 if unidad == 'Cuajone' else 20
            cx = cb * np.random.uniform(0.9, 1.1)
            if year >= 2024 and unidad == 'Toquepala':
                proy = 'Expansion Toquepala, Optimizacion Planta'
            elif year >= 2024 and unidad == 'Cuajone':
                proy = 'Modernizacion Cuajone'
            elif unidad == 'Fundicion Ilo':
                proy = 'Mejoras Ambientales'
            else:
                proy = 'Mantenimiento Mayor'
            data.append({'Año': year, 'Trimestre': quarter, 'Unidad_Operativa': unidad, 'Tipo_Operacion': info['tipo'], 'Produccion_Cobre_TM': round(pc, 2), 'Produccion_Molibdeno_TM': round(pm, 2), 'Produccion_Plata_Kg': round(pp, 2), 'Produccion_Zinc_TM': round(pz, 2), 'Produccion_Oro_Kg': round(po, 2), 'Capacidad_Instalada_TM_Dia': round(cd, 2), 'Utilizacion_Capacidad_Porcentaje': round(util, 2), 'Empleados_Directos': ed, 'Empleados_Contratistas': ec, 'Total_Empleados': te, 'Horas_Trabajadas': h, 'Accidentes_Trabajo': acc, 'Inversiones_Capex_USD': round(cx, 2), 'Proyectos_Expansion': proy, 'Produccion_Acido_Sulfurico_TM': round(pa, 2)})
    df = pd.DataFrame(data)
    logger.info(f"Datos empleo: {len(df)} registros")
    return df

def generate_competitor_data() -> pd.DataFrame:
    logger.info("Generando datos competencia...")
    quarters = date_utils.generate_quarters(2022, 2025)
    comp = {
        'Southern Peru': {'ctrl': 'Grupo Mexico', 'pais': 'Mexico', 'ubi': 'Tacna/Moquegua', 'pb': 108000, 'cc': 1.81, 'me': 0.58, 'emp': 8000, 'res': 12.5, 'vu': 35, 'pa': None},
        'Cerro Verde': {'ctrl': 'Freeport McMoRan', 'pais': 'Estados Unidos', 'ubi': 'Arequipa', 'pb': 240000, 'cc': 1.68, 'me': 0.59, 'emp': 6500, 'res': 18.2, 'vu': 42, 'pa': 45.5},
        'Antamina': {'ctrl': 'BHP-Glencore', 'pais': 'Reino Unido/Suiza', 'ubi': 'Ancash', 'pb': 135000, 'cc': 2.16, 'me': 0.57, 'emp': 5200, 'res': 8.5, 'vu': 28, 'pa': None},
        'Las Bambas': {'ctrl': 'MMG Limited', 'pais': 'China', 'ubi': 'Apurimac', 'pb': 110000, 'cc': 2.47, 'me': 0.56, 'emp': 4800, 'res': 6.8, 'vu': 24, 'pa': None},
        'Antapaccay': {'ctrl': 'Glencore', 'pais': 'Suiza', 'ubi': 'Cusco', 'pb': 80000, 'cc': 2.20, 'me': 0.57, 'emp': 3500, 'res': 5.2, 'vu': 22, 'pa': None}
    }
    data = []
    pb_dict = {2022: 4.2, 2023: 3.9, 2024: 4.3, 2025: 4.5}
    for year, quarter in quarters:
        np.random.seed(hash(f"{year}{quarter}") % 2**32)
        pcu = pb_dict[year] * np.random.uniform(0.95, 1.05)
        ys = year - 2022
        gr = 1 + (ys * 0.05)
        for emp_name, inf in comp.items():
            np.random.seed(hash(f"{year}{quarter}{emp_name}") % 2**32)
            pcu_prod = inf['pb'] * gr * np.random.uniform(0.95, 1.05)
            if emp_name in ['Antamina', 'Las Bambas']:
                pz, pag, pau = pcu_prod * 0.3, pcu_prod * 0.25, pcu_prod * 0.0015
            else:
                pz, pag, pau = 0, pcu_prod * 0.15, pcu_prod * 0.001
            vnt = (pcu_prod * 2204.62 * pcu) / 1_000_000
            ebt = vnt * inf['me']
            un = ebt * 0.65
            cpb = vnt * 0.15 if year >= 2024 else vnt * 0.12
            cpx = cpb * np.random.uniform(0.9, 1.1)
            empls = int(inf['emp'] * (1 + ys * 0.02))
            pa_val = round(inf['pa'] * np.random.uniform(0.95, 1.05), 2) if inf['pa'] else None
            data.append({'Año': year, 'Trimestre': quarter, 'Empresa': emp_name, 'Controlador': inf['ctrl'], 'Pais_Origen': inf['pais'], 'Ubicacion_Principal': inf['ubi'], 'Produccion_Cobre_TM': round(pcu_prod, 2), 'Produccion_Zinc_TM': round(pz, 2), 'Produccion_Plata_Kg': round(pag, 2), 'Produccion_Oro_Kg': round(pau, 2), 'Ventas_Netas_USD_Millones': round(vnt, 2), 'EBITDA_USD_Millones': round(ebt, 2), 'Utilidad_Neta_USD_Millones': round(un, 2), 'Margen_EBITDA_Porcentaje': round(inf['me'] * 100, 2), 'Empleados_Totales': empls, 'Inversiones_Capex_USD_Millones': round(cpx, 2), 'Costo_Cash_USD_Libra': round(inf['cc'] * np.random.uniform(0.98, 1.02), 2), 'Reservas_Probadas_Millones_TM': inf['res'], 'Vida_Util_Años': inf['vu'], 'Precio_Accion_USD': pa_val})
    df = pd.DataFrame(data)
    logger.info(f"Datos competencia: {len(df)} registros")
    return df
