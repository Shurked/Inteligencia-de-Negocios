"""
Extractor de datos de canon y regalias (MEF simulado).
Genera distribucion de transferencias fiscales por nivel de gobierno.
"""

import pandas as pd
import numpy as np
from loguru import logger

from config import settings
from utils import date_utils


def generate_canon_distribution(fiscal_df: pd.DataFrame) -> pd.DataFrame:
    """
    Genera distribucion de canon minero por nivel de gobierno.
    
    Args:
        fiscal_df: DataFrame con datos fiscales (IR pagado)
        
    Returns:
        DataFrame con distribucion de canon por departamento y nivel
        
    Columns:
        - Año, Trimestre, Departamento, Nivel_Gobierno
        - Tipo_Transferencia, Monto_Soles, Porcentaje_Total
    """
    logger.info("Generando distribucion de canon (MEF)...")
    
    data = []
    
    # Departamentos beneficiarios
    dept_distribution = {
        'Tacna': 0.55,      # Toquepala (55% produccion)
        'Moquegua': 0.45    # Cuajone + Fundicion (45% produccion)
    }
    
    for _, row in fiscal_df.iterrows():
        year = row['Año']
        quarter = row['Trimestre']
        ir_pagado = row['IR_Pagado_Soles']
        
        # Calcular canon (50% del IR)
        canon_total = ir_pagado * settings.TASA_CANON
        
        # Calcular regalias (5.1% de utilidad operativa)
        utilidad_op = row['Utilidad_Operativa_Soles']
        regalias_total = utilidad_op * settings.TASA_REGALIAS_PROMEDIO
        
        # Distribuir por departamento
        for dept, dept_pct in dept_distribution.items():
            canon_dept = canon_total * dept_pct
            regalias_dept = regalias_total * dept_pct
            
            # Distribuir canon por nivel de gobierno
            for nivel, nivel_pct in settings.DIST_CANON.items():
                monto_canon = canon_dept * nivel_pct
                
                data.append({
                    'Año': year,
                    'Trimestre': quarter,
                    'Departamento': dept,
                    'Nivel_Gobierno': nivel,
                    'Tipo_Transferencia': 'Canon Minero',
                    'Monto_Soles': round(monto_canon, 2),
                    'Porcentaje_Total': round(nivel_pct * 100, 2)
                })
            
            # Distribuir regalias por nivel de gobierno
            for nivel, nivel_pct in settings.DIST_REGALIAS.items():
                monto_regalias = regalias_dept * nivel_pct
                
                data.append({
                    'Año': year,
                    'Trimestre': quarter,
                    'Departamento': dept,
                    'Nivel_Gobierno': nivel,
                    'Tipo_Transferencia': 'Regalias Mineras',
                    'Monto_Soles': round(monto_regalias, 2),
                    'Porcentaje_Total': round(nivel_pct * 100, 2)
                })
    
    df = pd.DataFrame(data)
    logger.info(f"Distribucion de canon generada: {len(df)} registros")
    logger.debug(f"Canon total distribuido: S/ {df[df['Tipo_Transferencia']=='Canon Minero']['Monto_Soles'].sum():,.0f}")
    logger.debug(f"Regalias totales distribuidas: S/ {df[df['Tipo_Transferencia']=='Regalias Mineras']['Monto_Soles'].sum():,.0f}")
    
    return df


def expand_to_monthly(canon_df: pd.DataFrame, price_df: pd.DataFrame) -> pd.DataFrame:
    """
    Expande datos trimestrales a mensuales selectos con precios.
    
    Args:
        canon_df: DataFrame con distribucion trimestral
        price_df: DataFrame con precios mensuales
        
    Returns:
        DataFrame con registros mensuales expandidos
    """
    logger.info("Expandiendo datos a nivel mensual...")
    
    data = []
    
    for _, row in canon_df.iterrows():
        year = row['Año']
        quarter = row['Trimestre']
        
        # Obtener meses del trimestre
        months = date_utils.quarter_to_months(quarter)
        
        # Dividir monto trimestral entre 3 meses
        monto_mensual = row['Monto_Soles'] / 3
        
        # Generar registros para cada mes
        for month in months:
            # Obtener precio del cobre del mes
            precio_row = price_df[
                (price_df['Año'] == year) & 
                (price_df['Mes'] == month)
            ]
            
            precio_cobre = precio_row['Precio_Cobre_USD_Libra'].values[0] if len(precio_row) > 0 else 4.0
            
            data.append({
                'Año': year,
                'Trimestre': quarter,
                'Mes': month,
                'Departamento': row['Departamento'],
                'Nivel_Gobierno': row['Nivel_Gobierno'],
                'Tipo_Transferencia': row['Tipo_Transferencia'],
                'Monto_Soles': round(monto_mensual, 2),
                'Precio_Cobre_USD_Libra': precio_cobre
            })
    
    df = pd.DataFrame(data)
    logger.info(f"Datos mensuales expandidos: {len(df)} registros")
    
    return df
