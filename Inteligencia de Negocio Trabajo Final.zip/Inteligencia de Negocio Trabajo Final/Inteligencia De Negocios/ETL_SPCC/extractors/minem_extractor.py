"""
Extractor de datos de produccion minera (MINEM simulado).
Genera datos sinteticos realistas de produccion trimestral.
"""

import pandas as pd
import numpy as np
from typing import List, Dict
from loguru import logger

from config import settings
from utils import date_utils


def generate_production_data() -> pd.DataFrame:
    """
    Genera datos sinteticos de produccion minera trimestral para SPCC.
    
    Returns:
        DataFrame con produccion por unidad operativa y trimestre
        
    Columns:
        - Año, Trimestre, Unidad_Operativa
        - Produccion_Cobre_TM, Produccion_Molibdeno_TM, Produccion_Plata_Kg
    """
    logger.info("Generando datos de produccion minera (MINEM)...")
    
    # Generar trimestres
    quarters = date_utils.generate_quarters(2022, 2025)
    
    data = []
    
    # Produccion base por unidad (trimestral)
    prod_base = {
        'Toquepala': {
            'cobre': 60000,      # TM
            'molibdeno': 1800,   # TM
            'plata': 12000       # Kg
        },
        'Cuajone': {
            'cobre': 48000,      # TM
            'molibdeno': 1600,   # TM
            'plata': 10000       # Kg
        },
        'Fundicion Ilo': {
            'cobre': 0,          # No produce, solo procesa
            'molibdeno': 0,
            'plata': 0
        }
    }
    
    # Factor de crecimiento anual (~8% YoY)
    growth_rate = 1.08
    
    # Variacion estacional por trimestre
    seasonal_factors = {
        'Q1': 0.92,  # Menor produccion (lluvias, mantenimiento)
        'Q2': 0.98,
        'Q3': 1.05,
        'Q4': 1.08   # Mayor produccion
    }
    
    for year, quarter in quarters:
        # Factor de crecimiento acumulado
        years_since_base = year - 2022
        growth_factor = growth_rate ** years_since_base
        
        # Factor estacional
        seasonal = seasonal_factors[quarter]
        
        for unidad in settings.UNIDADES_SPCC:
            # Calcular produccion con tendencia y estacionalidad
            base_cobre = prod_base[unidad]['cobre']
            base_moly = prod_base[unidad]['molibdeno']
            base_plata = prod_base[unidad]['plata']
            
            # Aplicar factores y ruido aleatorio (±3-5%)
            np.random.seed(hash(f"{year}{quarter}{unidad}") % 2**32)
            noise = np.random.uniform(0.97, 1.03)
            
            prod_cobre = base_cobre * growth_factor * seasonal * noise
            prod_moly = base_moly * growth_factor * seasonal * noise
            prod_plata = base_plata * growth_factor * seasonal * noise
            
            data.append({
                'Año': year,
                'Trimestre': quarter,
                'Unidad_Operativa': unidad,
                'Produccion_Cobre_TM': round(prod_cobre, 2),
                'Produccion_Molibdeno_TM': round(prod_moly, 2),
                'Produccion_Plata_Kg': round(prod_plata, 2)
            })
    
    df = pd.DataFrame(data)
    logger.info(f"Datos de produccion generados: {len(df)} registros")
    logger.debug(f"Produccion total cobre: {df['Produccion_Cobre_TM'].sum():,.0f} TM")
    
    return df


def get_production_distribution() -> Dict[str, float]:
    """
    Retorna la distribucion porcentual de produccion por unidad.
    
    Returns:
        Diccionario con porcentaje de produccion por unidad
    """
    return {
        'Toquepala': 0.55,      # 55%
        'Cuajone': 0.45,        # 45%
        'Fundicion Ilo': 0.00   # 0%
    }
