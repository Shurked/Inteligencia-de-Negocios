"""
Extractor de precios del cobre (BCRP simulado).
Genera serie temporal de precios mensuales del cobre.
"""

import pandas as pd
import numpy as np
from loguru import logger

from config import settings
from utils import date_utils


def generate_copper_prices() -> pd.DataFrame:
    """
    Genera serie de precios mensuales del cobre (LME).
    
    Returns:
        DataFrame con precios mensuales
        
    Columns:
        - Año, Mes, Precio_Cobre_USD_Libra
    """
    logger.info("Generando precios del cobre (BCRP)...")
    
    data = []
    
    # Precios base por año con tendencia
    price_trends = {
        2022: {'base': 4.2, 'trend': 'alcista', 'volatility': 0.08},
        2023: {'base': 3.9, 'trend': 'lateral', 'volatility': 0.06},
        2024: {'base': 4.3, 'trend': 'recuperacion', 'volatility': 0.07},
        2025: {'base': 4.5, 'trend': 'alcista', 'volatility': 0.05}
    }
    
    for year in settings.AÑOS:
        trend_info = price_trends[year]
        base_price = trend_info['base']
        volatility = trend_info['volatility']
        
        # Determinar cuantos meses generar
        num_months = 12 if year < 2025 else 3  # Solo Q1 2025
        
        for month_idx in range(num_months):
            month_name = settings.MESES[month_idx]
            
            # Generar precio con tendencia y volatilidad
            np.random.seed(hash(f"{year}{month_idx}") % 2**32)
            
            # Factor de tendencia mensual
            if trend_info['trend'] == 'alcista':
                trend_factor = 1 + (month_idx / 12) * 0.05  # +5% anual
            elif trend_info['trend'] == 'lateral':
                trend_factor = 1 + np.sin(month_idx / 2) * 0.02  # Oscilacion
            else:  # recuperacion
                trend_factor = 1 + (month_idx / 12) * 0.08  # +8% anual
            
            # Ruido aleatorio
            noise = np.random.uniform(1 - volatility, 1 + volatility)
            
            precio = base_price * trend_factor * noise
            
            # Asegurar que este en rango valido
            precio = max(settings.PRECIO_COBRE_MIN, min(precio, settings.PRECIO_COBRE_MAX))
            
            data.append({
                'Año': year,
                'Mes': month_name,
                'Precio_Cobre_USD_Libra': round(precio, 2)
            })
    
    df = pd.DataFrame(data)
    logger.info(f"Precios del cobre generados: {len(df)} registros")
    logger.debug(f"Precio promedio: USD {df['Precio_Cobre_USD_Libra'].mean():.2f}/lb")
    logger.debug(f"Rango: USD {df['Precio_Cobre_USD_Libra'].min():.2f} - {df['Precio_Cobre_USD_Libra'].max():.2f}/lb")
    
    return df


def get_price_by_quarter(price_df: pd.DataFrame) -> pd.DataFrame:
    """
    Agrega precios mensuales a trimestrales.
    
    Args:
        price_df: DataFrame con precios mensuales
        
    Returns:
        DataFrame con precios promedio por trimestre
    """
    # Mapear meses a trimestres
    month_to_quarter = {}
    for q in ['Q1', 'Q2', 'Q3', 'Q4']:
        months = date_utils.quarter_to_months(q)
        for month in months:
            month_to_quarter[month] = q
    
    price_df['Trimestre'] = price_df['Mes'].map(month_to_quarter)
    
    # Agrupar por trimestre
    quarterly = price_df.groupby(['Año', 'Trimestre']).agg({
        'Precio_Cobre_USD_Libra': 'mean'
    }).reset_index()
    
    quarterly['Precio_Cobre_USD_Libra'] = quarterly['Precio_Cobre_USD_Libra'].round(2)
    
    return quarterly
