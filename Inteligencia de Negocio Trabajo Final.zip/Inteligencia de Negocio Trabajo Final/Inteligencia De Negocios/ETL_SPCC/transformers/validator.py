"""
Modulo de validacion de datos.
"""
import pandas as pd
from loguru import logger
from config import settings
from utils import validation_utils

def validate_all_data(datasets: dict) -> dict:
    logger.info("Iniciando validacion de datos...")
    results = {'all_passed': True, 'validations_run': 0, 'validations_passed': 0, 'validations_failed': 0, 'errors': []}
    for dataset_name, df in datasets.items():
        logger.info(f"Validando dataset: {dataset_name}")
        if dataset_name == 'operaciones':
            dataset_results = validate_operaciones(df)
        elif dataset_name == 'canon':
            dataset_results = validate_canon(df)
        elif dataset_name == 'empleo':
            dataset_results = validate_empleo(df)
        elif dataset_name == 'competencia':
            dataset_results = validate_competencia(df)
        else:
            logger.warning(f"Dataset desconocido: {dataset_name}")
            continue
        results['validations_run'] += dataset_results['total']
        results['validations_passed'] += dataset_results['passed']
        results['validations_failed'] += dataset_results['failed']
        results['errors'].extend(dataset_results['errors'])
        if dataset_results['failed'] > 0:
            results['all_passed'] = False
    logger.info(f"Validacion completada: {results['validations_passed']}/{results['validations_run']} validaciones pasadas")
    return results

def validate_operaciones(df: pd.DataFrame) -> dict:
    results = {'total': 0, 'passed': 0, 'failed': 0, 'errors': []}
    critical_cols = ['Produccion_Cobre_TM', 'Canon_Minero_Soles', 'Total_Transferencias_Soles']
    for col in critical_cols:
        if col in df.columns:
            results['total'] += 1
            null_count = df[col].isna().sum()
            if null_count == 0:
                results['passed'] += 1
            else:
                results['failed'] += 1
                results['errors'].append(f"Operaciones: {col} tiene {null_count} nulos")
    if 'Latitud' in df.columns and 'Longitud' in df.columns:
        for idx, row in df.head(10).iterrows():
            results['total'] += 1
            is_valid, msg = validation_utils.validate_coordinates(row['Latitud'], row['Longitud'])
            if is_valid:
                results['passed'] += 1
            else:
                results['failed'] += 1
                results['errors'].append(f"Operaciones fila {idx}: {msg}")
    return results

def validate_canon(df: pd.DataFrame) -> dict:
    results = {'total': 0, 'passed': 0, 'failed': 0, 'errors': []}
    if 'Precio_Cobre_USD_Libra' in df.columns:
        for idx, row in df.head(10).iterrows():
            results['total'] += 1
            precio = row['Precio_Cobre_USD_Libra']
            is_valid, msg = validation_utils.validate_range(precio, settings.PRECIO_COBRE_MIN, settings.PRECIO_COBRE_MAX, f"Precio cobre")
            if is_valid:
                results['passed'] += 1
            else:
                results['failed'] += 1
                results['errors'].append(f"Canon fila {idx}: {msg}")
    return results

def validate_empleo(df: pd.DataFrame) -> dict:
    results = {'total': 0, 'passed': 0, 'failed': 0, 'errors': []}
    if 'Total_Empleados' in df.columns:
        for idx, row in df.head(10).iterrows():
            results['total'] += 1
            is_valid, msg = validation_utils.validate_positive(row['Total_Empleados'], "Total empleados")
            if is_valid:
                results['passed'] += 1
            else:
                results['failed'] += 1
                results['errors'].append(f"Empleo fila {idx}: {msg}")
    if 'Utilizacion_Capacidad_Porcentaje' in df.columns:
        for idx, row in df.head(10).iterrows():
            results['total'] += 1
            util = row['Utilizacion_Capacidad_Porcentaje']
            is_valid, msg = validation_utils.validate_range(util, settings.UTILIZACION_MIN, settings.UTILIZACION_MAX, "Utilizacion")
            if is_valid:
                results['passed'] += 1
            else:
                results['failed'] += 1
                results['errors'].append(f"Empleo fila {idx}: {msg}")
    return results

def validate_competencia(df: pd.DataFrame) -> dict:
    results = {'total': 0, 'passed': 0, 'failed': 0, 'errors': []}
    if 'Margen_EBITDA_Porcentaje' in df.columns:
        for idx, row in df.head(10).iterrows():
            results['total'] += 1
            margen = row['Margen_EBITDA_Porcentaje']
            is_valid, msg = validation_utils.validate_range(margen, 40.0, 70.0, "Margen EBITDA")
            if is_valid:
                results['passed'] += 1
            else:
                results['failed'] += 1
                results['errors'].append(f"Competencia fila {idx}: {msg}")
    return results

def validate_canon_formula(df: pd.DataFrame) -> dict:
    results = {'total': 0, 'passed': 0, 'failed': 0, 'errors': []}
    if 'Canon_Minero_Soles' not in df.columns or 'IR_Pagado_Soles' not in df.columns:
        return results
    for idx, row in df.head(10).iterrows():
        results['total'] += 1
        canon = row['Canon_Minero_Soles']
        ir = row['IR_Pagado_Soles']
        expected_canon = ir * settings.TASA_CANON
        is_valid, msg = validation_utils.validate_formula(canon, expected_canon, 0.01, "Canon = 50% IR")
        if is_valid:
            results['passed'] += 1
        else:
            results['failed'] += 1
            results['errors'].append(msg)
    logger.info(f"Formula Canon validada: {results['passed']}/{results['total']}")
    return results

def validate_total_transferencias(df: pd.DataFrame) -> dict:
    results = {'total': 0, 'passed': 0, 'failed': 0, 'errors': []}
    required_cols = ['Canon_Minero_Soles', 'Regalias_Mineras_Soles', 'Derecho_Vigencia_Soles', 'IR_Pagado_Soles', 'Total_Transferencias_Soles']
    if not all(col in df.columns for col in required_cols):
        return results
    for idx, row in df.head(10).iterrows():
        results['total'] += 1
        total_calc = row['Canon_Minero_Soles'] + row['Regalias_Mineras_Soles'] + row['Derecho_Vigencia_Soles'] + row['IR_Pagado_Soles']
        total_reported = row['Total_Transferencias_Soles']
        is_valid, msg = validation_utils.validate_formula(total_reported, total_calc, 0.001, "Total transferencias")
        if is_valid:
            results['passed'] += 1
        else:
            results['failed'] += 1
            results['errors'].append(msg)
    logger.info(f"Total transferencias validado: {results['passed']}/{results['total']}")
    return results
