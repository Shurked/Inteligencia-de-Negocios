"""
Modulo de agregacion y calculos fiscales.
"""

import pandas as pd
from loguru import logger
from config import settings


def calculate_fiscal_metrics(financial_df: pd.DataFrame) -> pd.DataFrame:
    """
    Calcula metricas fiscales: Canon y Regalias.
    
    Args:
        financial_df: DataFrame con datos financieros (IR, Utilidad Op)
        
    Returns:
        DataFrame con metricas fiscales calculadas
    """
    logger.info("Calculando metricas fiscales...")
    
    df = financial_df.copy()
    
    # Calcular Canon (50% del IR)
    df['Canon_Minero_Soles'] = df['IR_Pagado_Soles'] * settings.TASA_CANON
    
    # Calcular Regalias (5.1% de Utilidad Operativa)
    df['Regalias_Mineras_Soles'] = df['Utilidad_Operativa_Soles'] * settings.TASA_REGALIAS_PROMEDIO
    
    # Calcular Derecho de Vigencia (estimado como porcentaje del IR)
    df['Derecho_Vigencia_Soles'] = df['IR_Pagado_Soles'] * 0.02  # ~2% del IR
    
    # Calcular Total de Transferencias
    df['Total_Transferencias_Soles'] = (
        df['Canon_Minero_Soles'] + 
        df['Regalias_Mineras_Soles'] + 
        df['Derecho_Vigencia_Soles'] +
        df['IR_Pagado_Soles']
    )
    
    logger.info(f"Metricas fiscales calculadas para {len(df)} registros")
    logger.debug(f"Canon total: S/ {df['Canon_Minero_Soles'].sum():,.0f}")
    logger.debug(f"Regalias totales: S/ {df['Regalias_Mineras_Soles'].sum():,.0f}")
    
    return df


def calculate_canon(ir_pagado: float) -> float:
    """
    Calcula el Canon Minero.
    
    Args:
        ir_pagado: Impuesto a la Renta pagado en Soles
        
    Returns:
        Canon Minero en Soles
    """
    return ir_pagado * settings.TASA_CANON


def calculate_regalias(utilidad_operativa: float) -> float:
    """
    Calcula las Regalias Mineras.
    
    Args:
        utilidad_operativa: Utilidad Operativa en Soles
        
    Returns:
        Regalias Mineras en Soles
    """
    return utilidad_operativa * settings.TASA_REGALIAS_PROMEDIO


def calculate_total_transferencias(canon: float, regalias: float, 
                                   derecho_vigencia: float, ir: float) -> float:
    """
    Calcula el total de transferencias fiscales.
    
    Args:
        canon: Canon Minero
        regalias: Regalias Mineras
        derecho_vigencia: Derecho de Vigencia
        ir: Impuesto a la Renta
        
    Returns:
        Total de transferencias
    """
    return canon + regalias + derecho_vigencia + ir


def aggregate_by_quarter(df: pd.DataFrame, value_column: str, 
                        group_columns: list) -> pd.DataFrame:
    """
    Agrega datos mensuales a trimestrales.
    
    Args:
        df: DataFrame con datos mensuales
        value_column: Columna de valores a sumar
        group_columns: Columnas para agrupar
        
    Returns:
        DataFrame agregado por trimestre
    """
    logger.info(f"Agregando datos por trimestre en columna '{value_column}'")
    
    # Asegurar que Trimestre este en las columnas de agrupacion
    if 'Trimestre' not in group_columns:
        group_columns = ['Año', 'Trimestre'] + [col for col in group_columns if col not in ['Año', 'Trimestre']]
    
    aggregated = df.groupby(group_columns)[value_column].sum().reset_index()
    
    logger.info(f"Agregacion completada: {len(aggregated)} registros")
    
    return aggregated


def distribute_canon_by_level(canon_total: float, nivel: str, 
                              tipo_transferencia: str = 'Canon') -> float:
    """
    Distribuye Canon o Regalias segun nivel de gobierno.
    
    Args:
        canon_total: Monto total a distribuir
        nivel: Nivel de gobierno
        tipo_transferencia: 'Canon' o 'Regalias'
        
    Returns:
        Monto distribuido para ese nivel
    """
    if tipo_transferencia == 'Canon':
        distribucion = settings.DIST_CANON
    elif tipo_transferencia == 'Regalias':
        distribucion = settings.DIST_REGALIAS
    else:
        logger.error(f"Tipo de transferencia invalido: {tipo_transferencia}")
        return 0.0
    
    porcentaje = distribucion.get(nivel, 0.0)
    return canon_total * porcentaje


def calculate_production_totals(prod_df: pd.DataFrame) -> pd.DataFrame:
    """
    Calcula totales de produccion por trimestre.
    
    Args:
        prod_df: DataFrame con produccion por unidad
        
    Returns:
        DataFrame con totales por trimestre
    """
    logger.info("Calculando totales de produccion...")
    
    totals = prod_df.groupby(['Año', 'Trimestre']).agg({
        'Produccion_Cobre_TM': 'sum',
        'Produccion_Molibdeno_TM': 'sum',
        'Produccion_Plata_Kg': 'sum'
    }).reset_index()
    
    totals.columns = ['Año', 'Trimestre', 
                     'Produccion_Total_Cobre_TM',
                     'Produccion_Total_Molibdeno_TM', 
                     'Produccion_Total_Plata_Kg']
    
    logger.info(f"Totales calculados: {len(totals)} registros")
    
    return totals
