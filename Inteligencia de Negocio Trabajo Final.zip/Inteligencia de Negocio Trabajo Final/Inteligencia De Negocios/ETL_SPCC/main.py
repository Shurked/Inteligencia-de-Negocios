"""
Proceso ETL principal - Southern Peru Copper Corporation
Orquesta la extraccion, transformacion y carga de datos.
"""
import sys
import time
from loguru import logger
from config.logging_config import setup_logging
from config import settings

from extractors import minem_extractor, smv_extractor, mef_extractor, bcrp_extractor, pdf_extractor
from transformers import data_cleaner, aggregator, enricher, validator
from loaders import csv_loader, excel_loader


def main():
    start_time = time.time()
    
    logger.info("="*60)
    logger.info("INICIO DEL PROCESO ETL - SOUTHERN PERU COPPER CORPORATION")
    logger.info("="*60)
    
    try:
        logger.info("")
        logger.info("--- FASE 1: EXTRACCION DE DATOS ---")
        
        logger.info("Extrayendo datos de produccion (MINEM)...")
        prod_data = minem_extractor.generate_production_data()
        logger.info(f"OK: {len(prod_data)} registros de produccion extraidos")
        
        logger.info("Extrayendo datos financieros (SMV)...")
        financial_data = smv_extractor.generate_financial_data(prod_data)
        logger.info(f"OK: {len(financial_data)} registros financieros extraidos")
        
        logger.info("Extrayendo precios del cobre (BCRP)...")
        price_data = bcrp_extractor.generate_copper_prices()
        logger.info(f"OK: {len(price_data)} registros de precios extraidos")
        
        logger.info("Extrayendo datos de empleo y CAPEX...")
        employment_data = pdf_extractor.generate_employment_data()
        logger.info(f"OK: {len(employment_data)} registros de empleo extraidos")
        
        logger.info("Extrayendo datos de competencia...")
        competitor_data = pdf_extractor.generate_competitor_data()
        logger.info(f"OK: {len(competitor_data)} registros de competencia extraidos")
        
        logger.info("")
        logger.info("--- FASE 2: TRANSFORMACION DE DATOS ---")
        
        logger.info("Limpiando datos...")
        prod_data_clean = data_cleaner.clean_dataframe(prod_data, ['Año', 'Trimestre', 'Unidad_Operativa'])
        financial_data_clean = data_cleaner.clean_dataframe(financial_data, ['Año', 'Trimestre'])
        logger.info("OK: Limpieza completada")
        
        logger.info("Calculando metricas fiscales (Canon y Regalias)...")
        fiscal_data = aggregator.calculate_fiscal_metrics(financial_data_clean)
        logger.info("OK: Metricas fiscales calculadas")
        
        logger.info("Generando distribucion de canon por nivel de gobierno...")
        canon_dist_data = mef_extractor.generate_canon_distribution(fiscal_data)
        logger.info(f"OK: {len(canon_dist_data)} registros de distribucion generados")
        
        logger.info("Enriqueciendo datos de produccion...")
        prod_data_enriched = enricher.add_geospatial_data(prod_data_clean)
        prod_data_enriched = enricher.add_totals(prod_data_enriched, fiscal_data)
        logger.info("OK: Datos enriquecidos con coordenadas y metricas fiscales")
        
        logger.info("Integrando precios del cobre...")
        canon_with_prices = enricher.merge_price_data(canon_dist_data, price_data)
        logger.info("OK: Precios del cobre integrados")
        
        logger.info("Expandiendo datos a nivel mensual...")
        canon_monthly = mef_extractor.expand_to_monthly(canon_dist_data, price_data)
        logger.info(f"OK: {len(canon_monthly)} registros mensuales generados")
        
        logger.info("Agregando datos de produccion y utilidad operativa a canon mensual...")
        prod_totals = aggregator.calculate_production_totals(prod_data_clean)
        canon_monthly = enricher.merge_price_data(canon_monthly, price_data)
        canon_final = canon_monthly.merge(
            fiscal_data[['Año', 'Trimestre', 'Utilidad_Operativa_Soles', 'IR_Pagado_Soles', 'Tasa_Efectiva_IR']],
            on=['Año', 'Trimestre'],
            how='left'
        )
        canon_final = canon_final.merge(
            prod_totals[['Año', 'Trimestre', 'Produccion_Total_Cobre_TM']],
            on=['Año', 'Trimestre'],
            how='left'
        )
        canon_final.rename(columns={'Produccion_Total_Cobre_TM': 'Produccion_Cobre_TM'}, inplace=True)
        logger.info("OK: Canon enriquecido con produccion y utilidad operativa")
        
        logger.info("")
        logger.info("--- FASE 3: VALIDACION DE DATOS ---")
        
        validation_results = validator.validate_all_data({
            'operaciones': prod_data_enriched,
            'canon': canon_final,
            'empleo': employment_data,
            'competencia': competitor_data
        })
        
        if validation_results['all_passed']:
            logger.info("OK: Todas las validaciones pasaron exitosamente")
        else:
            logger.warning(f"ADVERTENCIA: {validation_results['validations_failed']} validaciones fallaron")
            for error in validation_results['errors'][:5]:
                logger.warning(f"  - {error}")
            if len(validation_results['errors']) > 5:
                logger.warning(f"  ... y {len(validation_results['errors']) - 5} errores mas")
        
        logger.info("")
        logger.info("--- FASE 4: PREPARACION DE DATASETS FINALES ---")
        
        logger.info("Generando tabla de coordenadas geoespaciales...")
        coordinates_table = enricher.generate_coordinates_table()
        logger.info(f"OK: {len(coordinates_table)} ubicaciones estrategicas")
        
        logger.info("Generando distribucion detallada de canon...")
        distribution_detail = enricher.generate_distribution_detail(canon_dist_data)
        logger.info(f"OK: {len(distribution_detail)} registros de distribucion detallada")
        
        output_files = {
            '01_Operaciones_Recaudacion_Regional': prod_data_enriched,
            '02_Canon_Regalias_Tendencias': canon_final,
            '03_Produccion_Capacidad_Empleo': employment_data,
            '04_Analisis_Competencia': competitor_data,
            '05_Coordenadas_Geoespaciales': coordinates_table,
            '06_Distribucion_Canon_Detallada': distribution_detail
        }
        
        logger.info("")
        logger.info("--- FASE 5: CARGA DE DATOS (EXPORT) ---")
        
        logger.info("Exportando archivos CSV...")
        for filename, df in output_files.items():
            csv_loader.save_to_csv(df, filename)
        logger.info(f"OK: {len(output_files)} archivos CSV guardados")
        
        logger.info("Exportando archivos Excel con formato...")
        for filename, df in output_files.items():
            excel_loader.save_to_excel_formatted(df, filename)
        logger.info(f"OK: {len(output_files)} archivos Excel guardados")
        
        logger.info("")
        logger.info("="*60)
        logger.info("PROCESO ETL COMPLETADO EXITOSAMENTE")
        logger.info("="*60)
        
        elapsed = time.time() - start_time
        logger.info(f"Tiempo total de ejecucion: {elapsed:.2f} segundos")
        logger.info(f"Archivos generados: {len(output_files) * 2} (CSV + XLSX)")
        
        total_records = sum(len(df) for df in output_files.values())
        logger.info(f"Total de registros procesados: {total_records:,}")
        logger.info(f"Ubicacion de salida: {settings.DATA_OUTPUT_DIR}")
        logger.info("")
        
        logger.info("RESUMEN DE ARCHIVOS GENERADOS:")
        for filename, df in output_files.items():
            logger.info(f"  - {filename}: {len(df)} registros, {len(df.columns)} columnas")
        
        logger.info("")
        logger.info("Siguiente paso: Importar archivos CSV/XLSX a Power BI")
        
    except Exception as e:
        logger.critical(f"ERROR CRITICO EN EL PROCESO ETL: {e}")
        logger.exception(e)
        sys.exit(1)


if __name__ == "__main__":
    setup_logging(log_level="INFO")
    main()
