"""
Modulo de cargadores de datos.
"""

from . import csv_loader
from . import excel_loader

__all__ = ['csv_loader', 'excel_loader']
