"""
Modulo de carga de datos en formato Excel con formato profesional.
"""

import pandas as pd
import os
from loguru import logger
from config import settings


def save_to_excel_formatted(df: pd.DataFrame, filename: str, output_dir: str = None) -> str:
    """
    Guarda DataFrame a Excel con formato profesional.
    
    Args:
        df: DataFrame a guardar
        filename: Nombre del archivo (sin extension)
        output_dir: Directorio de salida
        
    Returns:
        Path completo del archivo guardado
    """
    if output_dir is None:
        output_dir = settings.DATA_OUTPUT_DIR
    
    os.makedirs(output_dir, exist_ok=True)
    
    if not filename.endswith('.xlsx'):
        filename = f"{filename}.xlsx"
    
    filepath = os.path.join(output_dir, filename)
    
    try:
        # Usar xlsxwriter para formato avanzado
        writer = pd.ExcelWriter(filepath, engine='xlsxwriter')
        
        # Escribir DataFrame
        df.to_excel(writer, sheet_name='Datos', index=False)
        
        # Obtener objetos de workbook y worksheet
        workbook = writer.book
        worksheet = writer.sheets['Datos']
        
        # Definir formatos
        header_format = workbook.add_format({
            'bold': True,
            'bg_color': '#D3D3D3',
            'border': 1,
            'align': 'center',
            'valign': 'vcenter'
        })
        
        money_format_soles = workbook.add_format({
            'num_format': 'S/ #,##0.00',
            'border': 1
        })
        
        money_format_usd = workbook.add_format({
            'num_format': 'USD #,##0.00',
            'border': 1
        })
        
        percent_format = workbook.add_format({
            'num_format': '0.00%',
            'border': 1
        })
        
        number_format = workbook.add_format({
            'num_format': '#,##0.00',
            'border': 1
        })
        
        integer_format = workbook.add_format({
            'num_format': '#,##0',
            'border': 1
        })
        
        # Aplicar formato a encabezados
        for col_num, value in enumerate(df.columns.values):
            worksheet.write(0, col_num, value, header_format)
        
        # Aplicar formatos a columnas segun tipo
        for col_num, col_name in enumerate(df.columns):
            # Determinar ancho de columna
            max_len = max(
                df[col_name].astype(str).map(len).max(),
                len(col_name)
            )
            col_width = min(max_len + 2, 50)
            worksheet.set_column(col_num, col_num, col_width)
            
            # Aplicar formato segun nombre de columna
            if '_Soles' in col_name or col_name.startswith('Monto_'):
                # Formato moneda soles
                for row_num in range(1, len(df) + 1):
                    worksheet.write(row_num, col_num, df.iloc[row_num-1][col_name], money_format_soles)
            
            elif '_USD' in col_name or col_name.startswith('Precio_'):
                # Formato moneda USD
                for row_num in range(1, len(df) + 1):
                    worksheet.write(row_num, col_num, df.iloc[row_num-1][col_name], money_format_usd)
            
            elif '_Porcentaje' in col_name or col_name.endswith('_Pct'):
                # Formato porcentaje (dividir por 100 ya que el dato viene como 50, no 0.5)
                for row_num in range(1, len(df) + 1):
                    value = df.iloc[row_num-1][col_name]
                    if pd.notna(value):
                        worksheet.write(row_num, col_num, value / 100, percent_format)
            
            elif col_name in ['Empleados_Directos', 'Empleados_Contratistas', 'Total_Empleados', 
                             'Horas_Trabajadas', 'Accidentes_Trabajo', 'Proyectos_Financiados',
                             'Año', 'Altitud_msnm', 'Poblacion_Area_Influencia', 'Año_Inicio_Operaciones']:
                # Formato entero
                for row_num in range(1, len(df) + 1):
                    worksheet.write(row_num, col_num, df.iloc[row_num-1][col_name], integer_format)
            
            elif df[col_name].dtype in ['float64', 'int64'] and col_name not in ['Año', 'Latitud', 'Longitud']:
                # Formato numero con decimales
                for row_num in range(1, len(df) + 1):
                    worksheet.write(row_num, col_num, df.iloc[row_num-1][col_name], number_format)
        
        # Congelar primera fila
        worksheet.freeze_panes(1, 0)
        
        # Activar filtros automaticos
        worksheet.autofilter(0, 0, len(df), len(df.columns) - 1)
        
        # Cerrar writer
        writer.close()
        
        logger.info(f"Excel guardado: {filepath} ({len(df)} registros, {len(df.columns)} columnas)")
        
        if os.path.exists(filepath):
            file_size = os.path.getsize(filepath)
            logger.debug(f"Tamaño del archivo: {file_size:,} bytes")
        
        return filepath
        
    except Exception as e:
        logger.error(f"Error al guardar Excel {filename}: {e}")
        raise


def save_multiple_excel(datasets: dict, output_dir: str = None) -> dict:
    """
    Guarda multiples DataFrames a Excel.
    
    Args:
        datasets: Diccionario {nombre_archivo: DataFrame}
        output_dir: Directorio de salida
        
    Returns:
        Diccionario {nombre_archivo: filepath}
    """
    logger.info(f"Guardando {len(datasets)} archivos Excel...")
    
    saved_files = {}
    
    for filename, df in datasets.items():
        try:
            filepath = save_to_excel_formatted(df, filename, output_dir)
            saved_files[filename] = filepath
        except Exception as e:
            logger.error(f"Error guardando {filename}: {e}")
            saved_files[filename] = None
    
    successful = sum(1 for v in saved_files.values() if v is not None)
    logger.info(f"Archivos Excel guardados exitosamente: {successful}/{len(datasets)}")
    
    return saved_files
