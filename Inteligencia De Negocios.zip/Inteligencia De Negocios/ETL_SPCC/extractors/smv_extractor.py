"""
Extractor de datos financieros (SMV simulado).
Genera datos sinteticos de estados financieros trimestrales.
"""

import pandas as pd
import numpy as np
from loguru import logger

from config import settings
from utils import date_utils


def generate_financial_data(production_df: pd.DataFrame) -> pd.DataFrame:
    """
    Genera datos financieros basados en produccion.
    
    Args:
        production_df: DataFrame con datos de produccion
        
    Returns:
        DataFrame con datos financieros trimestrales
        
    Columns:
        - Año, Trimestre
        - Produccion_Total_Cobre_TM
        - Ventas_Netas_USD_Millones, EBITDA_USD_Millones
        - Utilidad_Operativa_Soles, Utilidad_Antes_IR_Soles
        - IR_Pagado_Soles, Utilidad_Neta_Soles
        - Tasa_Efectiva_IR, Margen_EBITDA_Porcentaje
    """
    logger.info("Generando datos financieros (SMV)...")
    
    # Agrupar produccion por trimestre (solo unidades productivas)
    prod_quarterly = production_df[
        production_df['Unidad_Operativa'] != 'Fundicion Ilo'
    ].groupby(['Año', 'Trimestre']).agg({
        'Produccion_Cobre_TM': 'sum',
        'Produccion_Molibdeno_TM': 'sum',
        'Produccion_Plata_Kg': 'sum'
    }).reset_index()
    
    # Generar precios promedio por trimestre
    precio_cobre_base = {
        2022: 4.2,   # USD/libra
        2023: 3.9,
        2024: 4.3,
        2025: 4.5
    }
    
    data = []
    
    for _, row in prod_quarterly.iterrows():
        year = row['Año']
        quarter = row['Trimestre']
        prod_cobre_tm = row['Produccion_Cobre_TM']
        prod_moly_tm = row['Produccion_Molibdeno_TM']
        prod_plata_kg = row['Produccion_Plata_Kg']
        
        # Precio promedio del trimestre con variacion
        np.random.seed(hash(f"{year}{quarter}") % 2**32)
        precio_cu = precio_cobre_base[year] * np.random.uniform(0.95, 1.05)
        precio_mo = 18.5 * np.random.uniform(0.95, 1.05)  # USD/libra molibdeno
        precio_ag = 22.0 * np.random.uniform(0.95, 1.05)  # USD/onza plata
        
        # Calcular ventas (convertir TM a libras)
        # 1 TM = 2204.62 libras
        ventas_cu = (prod_cobre_tm * 2204.62 * precio_cu) / 1_000_000  # Millones USD
        ventas_mo = (prod_moly_tm * 2204.62 * precio_mo) / 1_000_000
        # 1 Kg = 32.15 onzas
        ventas_ag = (prod_plata_kg * 32.15 * precio_ag) / 1_000_000
        
        ventas_totales = ventas_cu + ventas_mo + ventas_ag
        
        # Margenes operativos
        margen_ebitda = np.random.uniform(0.57, 0.59)  # 57-59%
        ebitda = ventas_totales * margen_ebitda
        
        # Utilidad operativa (EBITDA - D&A ~10%)
        utilidad_op = ebitda * 0.90
        
        # Utilidad antes de impuestos (descontar gastos financieros ~5%)
        utilidad_antes_ir = utilidad_op * 0.95
        
        # Impuesto a la renta (29.5%)
        ir_pagado = utilidad_antes_ir * settings.TASA_IR
        
        # Utilidad neta
        utilidad_neta = utilidad_antes_ir - ir_pagado
        
        # Convertir a soles (tipo de cambio promedio ~3.75)
        tipo_cambio = 3.75 * np.random.uniform(0.98, 1.02)
        
        utilidad_op_soles = utilidad_op * 1_000_000 * tipo_cambio
        utilidad_antes_ir_soles = utilidad_antes_ir * 1_000_000 * tipo_cambio
        ir_pagado_soles = ir_pagado * 1_000_000 * tipo_cambio
        utilidad_neta_soles = utilidad_neta * 1_000_000 * tipo_cambio
        
        data.append({
            'Año': year,
            'Trimestre': quarter,
            'Produccion_Total_Cobre_TM': round(prod_cobre_tm, 2),
            'Precio_Cobre_USD_Libra': round(precio_cu, 2),
            'Ventas_Netas_USD_Millones': round(ventas_totales, 2),
            'EBITDA_USD_Millones': round(ebitda, 2),
            'Margen_EBITDA_Porcentaje': round(margen_ebitda * 100, 2),
            'Utilidad_Operativa_Soles': round(utilidad_op_soles, 2),
            'Utilidad_Antes_IR_Soles': round(utilidad_antes_ir_soles, 2),
            'IR_Pagado_Soles': round(ir_pagado_soles, 2),
            'Utilidad_Neta_Soles': round(utilidad_neta_soles, 2),
            'Tasa_Efectiva_IR': round(settings.TASA_IR * 100, 2)
        })
    
    df = pd.DataFrame(data)
    logger.info(f"Datos financieros generados: {len(df)} registros")
    logger.debug(f"Ventas totales: USD {df['Ventas_Netas_USD_Millones'].sum():,.0f}M")
    logger.debug(f"IR total pagado: S/ {df['IR_Pagado_Soles'].sum():,.0f}")
    
    return df
