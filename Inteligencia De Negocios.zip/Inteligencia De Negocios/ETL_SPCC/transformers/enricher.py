"""
Modulo de enriquecimiento de datos.
"""
import pandas as pd
from loguru import logger
from config import settings

def add_geospatial_data(df: pd.DataFrame) -> pd.DataFrame:
    logger.info("Agregando datos geoespaciales...")
    df_enriched = df.copy()
    df_enriched['Latitud'] = df_enriched['Unidad_Operativa'].map(lambda x: settings.COORDENADAS.get(x, {}).get('lat', None))
    df_enriched['Longitud'] = df_enriched['Unidad_Operativa'].map(lambda x: settings.COORDENADAS.get(x, {}).get('lon', None))
    df_enriched['Departamento'] = df_enriched['Unidad_Operativa'].map(lambda x: settings.COORDENADAS.get(x, {}).get('dept', None))
    df_enriched['Region'] = 'Sur'
    provincia_map = {'Toquepala': 'Jorge Basadre', 'Cuajone': 'Mariscal Nieto', 'Fundicion Ilo': 'Ilo'}
    distrito_map = {'Toquepala': 'Ilabaya', 'Cuajone': 'Torata', 'Fundicion Ilo': 'Ilo'}
    df_enriched['Provincia'] = df_enriched['Unidad_Operativa'].map(provincia_map)
    df_enriched['Distrito'] = df_enriched['Unidad_Operativa'].map(distrito_map)
    logger.info(f"Datos geoespaciales agregados a {len(df_enriched)} registros")
    return df_enriched

def add_totals(prod_df: pd.DataFrame, fiscal_df: pd.DataFrame) -> pd.DataFrame:
    logger.info("Combinando produccion con metricas fiscales...")
    merged = pd.merge(prod_df, fiscal_df[['Año', 'Trimestre', 'Canon_Minero_Soles', 'Regalias_Mineras_Soles', 'Derecho_Vigencia_Soles', 'IR_Pagado_Soles', 'Total_Transferencias_Soles']], on=['Año', 'Trimestre'], how='left')
    for idx, row in merged.iterrows():
        unidad = row['Unidad_Operativa']
        factor = 0.55 if unidad == 'Toquepala' else 0.45 if unidad == 'Cuajone' else 0.0
        merged.at[idx, 'Canon_Minero_Soles'] = row['Canon_Minero_Soles'] * factor
        merged.at[idx, 'Regalias_Mineras_Soles'] = row['Regalias_Mineras_Soles'] * factor
        merged.at[idx, 'Derecho_Vigencia_Soles'] = row['Derecho_Vigencia_Soles'] * factor
        merged.at[idx, 'IR_Pagado_Soles'] = row['IR_Pagado_Soles'] * factor
        merged.at[idx, 'Total_Transferencias_Soles'] = row['Total_Transferencias_Soles'] * factor
    logger.info(f"Datos combinados: {len(merged)} registros")
    return merged

def merge_price_data(canon_df: pd.DataFrame, price_df: pd.DataFrame) -> pd.DataFrame:
    logger.info("Integrando precios del cobre...")
    if 'Mes' in price_df.columns:
        month_to_q = {}
        for q in ['Q1', 'Q2', 'Q3', 'Q4']:
            months = ['Enero', 'Febrero', 'Marzo'] if q == 'Q1' else ['Abril', 'Mayo', 'Junio'] if q == 'Q2' else ['Julio', 'Agosto', 'Septiembre'] if q == 'Q3' else ['Octubre', 'Noviembre', 'Diciembre']
            for m in months:
                month_to_q[m] = q
        price_df['Trimestre'] = price_df['Mes'].map(month_to_q)
        price_quarterly = price_df.groupby(['Año', 'Trimestre']).agg({'Precio_Cobre_USD_Libra': 'mean'}).reset_index()
    else:
        price_quarterly = price_df.copy()
    merged = pd.merge(canon_df, price_quarterly[['Año', 'Trimestre', 'Precio_Cobre_USD_Libra']], on=['Año', 'Trimestre'], how='left')
    logger.info(f"Precios integrados: {len(merged)} registros")
    return merged

def generate_coordinates_table() -> pd.DataFrame:
    logger.info("Generando tabla de coordenadas...")
    data = [
        {'Unidad_Operativa': 'Toquepala', 'Tipo': 'Mina', 'Departamento': 'Tacna', 'Provincia': 'Jorge Basadre', 'Distrito': 'Ilabaya', 'Latitud': -17.2544, 'Longitud': -70.5844, 'Altitud_msnm': 3100, 'Area_Concesion_Ha': 18500, 'Año_Inicio_Operaciones': 1960, 'Estado_Operativo': 'Operativo', 'Comunidades_Influencia': 'Ilabaya, Borogana, Calaluna', 'Poblacion_Area_Influencia': 8500},
        {'Unidad_Operativa': 'Cuajone', 'Tipo': 'Mina', 'Departamento': 'Moquegua', 'Provincia': 'Mariscal Nieto', 'Distrito': 'Torata', 'Latitud': -16.9842, 'Longitud': -70.7654, 'Altitud_msnm': 3600, 'Area_Concesion_Ha': 12800, 'Año_Inicio_Operaciones': 1976, 'Estado_Operativo': 'Operativo', 'Comunidades_Influencia': 'Torata, Cuajone, Yacango', 'Poblacion_Area_Influencia': 6200},
        {'Unidad_Operativa': 'Fundicion Ilo', 'Tipo': 'Fundicion', 'Departamento': 'Moquegua', 'Provincia': 'Ilo', 'Distrito': 'Ilo', 'Latitud': -17.6386, 'Longitud': -71.3375, 'Altitud_msnm': 15, 'Area_Concesion_Ha': 450, 'Año_Inicio_Operaciones': 1960, 'Estado_Operativo': 'Operativo', 'Comunidades_Influencia': 'Ilo, Pacocha', 'Poblacion_Area_Influencia': 65000}
    ]
    df = pd.DataFrame(data)
    logger.info(f"Tabla de coordenadas generada: {len(df)} ubicaciones")
    return df

def generate_distribution_detail(canon_df: pd.DataFrame) -> pd.DataFrame:
    logger.info("Generando distribucion detallada de canon...")
    data = []
    for _, row in canon_df.iterrows():
        nivel = row['Nivel_Gobierno']
        dept = row['Departamento']
        if 'Distrito' in nivel:
            entidad = f"Municipalidad Distrital {dept}"
            tipo_entidad = 'Distrito'
        elif 'Provincia' in nivel:
            entidad = f"Municipalidad Provincial {dept}"
            tipo_entidad = 'Provincia'
        elif 'Departamento' in nivel:
            entidad = f"Municipalidades Departamento {dept}"
            tipo_entidad = 'Departamento'
        elif 'Regional' in nivel:
            entidad = f"Gobierno Regional {dept}"
            tipo_entidad = 'Regional'
        else:
            entidad = f"Universidad Nacional {dept}"
            tipo_entidad = 'Universidad'
        import numpy as np
        np.random.seed(hash(f"{row['Año']}{row['Trimestre']}{dept}{nivel}") % 2**32)
        proyectos = int(np.random.uniform(5, 15))
        ejecucion_pct = np.random.uniform(70, 95)
        monto_ejecutado = row['Monto_Soles'] * (ejecucion_pct / 100)
        sectores = 'Infraestructura Vial, Educacion, Salud'
        data.append({'Año': row['Año'], 'Trimestre': row['Trimestre'], 'Departamento': dept, 'Nivel_Gobierno': nivel, 'Entidad_Beneficiaria': entidad, 'Tipo_Entidad': tipo_entidad, 'Monto_Canon_Soles': round(row['Monto_Soles'], 2), 'Porcentaje_Total': row['Porcentaje_Total'], 'Proyectos_Financiados': proyectos, 'Monto_Ejecutado_Soles': round(monto_ejecutado, 2), 'Porcentaje_Ejecucion': round(ejecucion_pct, 2), 'Principales_Sectores_Inversion': sectores})
    df = pd.DataFrame(data)
    logger.info(f"Distribucion detallada generada: {len(df)} registros")
    return df
