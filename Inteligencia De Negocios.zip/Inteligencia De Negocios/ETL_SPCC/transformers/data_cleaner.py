"""
Modulo de limpieza de datos.
"""

import pandas as pd
from loguru import logger
from typing import List, Optional
from utils import text_utils


def clean_dataframe(df: pd.DataFrame, key_columns: Optional[List[str]] = None) -> pd.DataFrame:
    """
    Limpieza general de DataFrame.
    
    Args:
        df: DataFrame a limpiar
        key_columns: Columnas clave para eliminar duplicados
        
    Returns:
        DataFrame limpio
    """
    logger.info(f"Limpiando DataFrame con {len(df)} registros")
    
    initial_rows = len(df)
    df_clean = df.copy()
    
    # Eliminar duplicados si se especifican columnas clave
    if key_columns:
        df_clean = remove_duplicates(df_clean, key_columns)
    
    # Estandarizar campos de texto
    df_clean = standardize_text_fields(df_clean)
    
    rows_cleaned = initial_rows - len(df_clean)
    if rows_cleaned > 0:
        logger.info(f"Registros eliminados en limpieza: {rows_cleaned}")
    
    logger.info(f"Limpieza completada: {len(df_clean)} registros")
    
    return df_clean


def remove_duplicates(df: pd.DataFrame, key_columns: List[str]) -> pd.DataFrame:
    """
    Elimina duplicados basado en columnas clave.
    
    Args:
        df: DataFrame con posibles duplicados
        key_columns: Columnas que forman la clave compuesta
        
    Returns:
        DataFrame sin duplicados
    """
    initial_count = len(df)
    
    # Verificar que las columnas clave existan
    missing_cols = set(key_columns) - set(df.columns)
    if missing_cols:
        logger.warning(f"Columnas clave no encontradas: {missing_cols}")
        return df
    
    df_clean = df.drop_duplicates(subset=key_columns, keep='first')
    
    duplicates_removed = initial_count - len(df_clean)
    if duplicates_removed > 0:
        logger.info(f"Duplicados eliminados: {duplicates_removed}")
    
    return df_clean


def fill_missing_values(df: pd.DataFrame, fill_strategies: dict) -> pd.DataFrame:
    """
    Imputa valores faltantes segun estrategias definidas.
    
    Args:
        df: DataFrame con valores faltantes
        fill_strategies: Dict con columna -> estrategia ('mean', 'median', 'zero', valor)
        
    Returns:
        DataFrame con valores imputados
    """
    df_filled = df.copy()
    
    for column, strategy in fill_strategies.items():
        if column not in df_filled.columns:
            continue
        
        missing_count = df_filled[column].isna().sum()
        if missing_count == 0:
            continue
        
        if strategy == 'mean':
            fill_value = df_filled[column].mean()
        elif strategy == 'median':
            fill_value = df_filled[column].median()
        elif strategy == 'zero':
            fill_value = 0
        else:
            fill_value = strategy
        
        df_filled[column].fillna(fill_value, inplace=True)
        logger.debug(f"Columna '{column}': {missing_count} valores imputados con {strategy}")
    
    return df_filled


def standardize_text_fields(df: pd.DataFrame) -> pd.DataFrame:
    """
    Estandariza campos de texto (nombres, categorias).
    
    Args:
        df: DataFrame con campos de texto
        
    Returns:
        DataFrame con texto estandarizado
    """
    df_std = df.copy()
    
    # Estandarizar departamentos si existe la columna
    if 'Departamento' in df_std.columns:
        df_std['Departamento'] = df_std['Departamento'].apply(
            lambda x: text_utils.standardize_department(str(x)) if pd.notna(x) else x
        )
    
    # Estandarizar empresas si existe la columna
    if 'Empresa' in df_std.columns:
        df_std['Empresa'] = df_std['Empresa'].apply(
            lambda x: text_utils.standardize_company_name(str(x)) if pd.notna(x) else x
        )
    
    # Limpiar espacios en blanco en todas las columnas de texto
    text_columns = df_std.select_dtypes(include=['object']).columns
    for col in text_columns:
        df_std[col] = df_std[col].apply(
            lambda x: text_utils.clean_whitespace(str(x)) if pd.notna(x) else x
        )
    
    return df_std


def validate_no_nulls(df: pd.DataFrame, critical_columns: List[str]) -> bool:
    """
    Valida que no haya valores nulos en columnas criticas.
    
    Args:
        df: DataFrame a validar
        critical_columns: Columnas que no deben tener nulos
        
    Returns:
        True si pasa validacion, False si hay nulos
    """
    has_nulls = False
    
    for col in critical_columns:
        if col not in df.columns:
            logger.warning(f"Columna critica '{col}' no encontrada")
            continue
        
        null_count = df[col].isna().sum()
        if null_count > 0:
            logger.error(f"Columna critica '{col}' tiene {null_count} valores nulos")
            has_nulls = True
    
    return not has_nulls
