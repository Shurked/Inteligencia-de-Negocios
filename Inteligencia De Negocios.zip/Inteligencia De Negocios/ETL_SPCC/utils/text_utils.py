"""
Utilidades para limpieza y estandarizacion de texto.
"""

import re
from typing import Union


def clean_numeric_string(value: str) -> float:
    """
    Limpia string numerico removiendo simbolos y convirtiendo a float.
    
    Args:
        value: String con numero (puede tener S/, $, comas, etc.)
        
    Returns:
        Valor numerico como float
        
    Example:
        >>> clean_numeric_string('S/ 1,234.56')
        1234.56
        >>> clean_numeric_string('$2.5M')
        2500000.0
    """
    if isinstance(value, (int, float)):
        return float(value)
    
    # Remover simbolos de moneda y espacios
    cleaned = re.sub(r'[S/\$USD\s,]', '', str(value))
    
    # Manejar millones/miles
    if 'M' in cleaned.upper():
        cleaned = cleaned.upper().replace('M', '')
        return float(cleaned) * 1_000_000
    elif 'K' in cleaned.upper():
        cleaned = cleaned.upper().replace('K', '')
        return float(cleaned) * 1_000
    
    try:
        return float(cleaned)
    except ValueError:
        return 0.0


def standardize_company_name(name: str) -> str:
    """
    Estandariza nombres de empresas mineras.
    
    Args:
        name: Nombre de la empresa (puede estar en diferentes formatos)
        
    Returns:
        Nombre estandarizado
        
    Example:
        >>> standardize_company_name('southern copper')
        'Southern Peru'
    """
    name_map = {
        'southern peru': 'Southern Peru',
        'spcc': 'Southern Peru',
        'southern copper': 'Southern Peru',
        'cerro verde': 'Cerro Verde',
        'antamina': 'Antamina',
        'las bambas': 'Las Bambas',
        'antapaccay': 'Antapaccay'
    }
    return name_map.get(name.lower(), name)


def standardize_department(dept: str) -> str:
    """
    Estandariza nombres de departamentos del Peru.
    
    Args:
        dept: Nombre del departamento (puede estar en minusculas/mayusculas)
        
    Returns:
        Nombre estandarizado con tildes y capitalizacion correcta
        
    Example:
        >>> standardize_department('tacna')
        'Tacna'
        >>> standardize_department('MOQUEGUA')
        'Moquegua'
    """
    dept_map = {
        'tacna': 'Tacna',
        'moquegua': 'Moquegua',
        'arequipa': 'Arequipa',
        'ancash': 'Ancash',
        'apurimac': 'Apurimac',
        'cusco': 'Cusco',
        'lima': 'Lima',
        'junin': 'Junin'
    }
    return dept_map.get(dept.lower(), dept.title())


def standardize_province(province: str) -> str:
    """
    Estandariza nombres de provincias.
    
    Args:
        province: Nombre de la provincia
        
    Returns:
        Nombre estandarizado
    """
    province_map = {
        'tacna': 'Tacna',
        'candarave': 'Candarave',
        'jorge basadre': 'Jorge Basadre',
        'tarata': 'Tarata',
        'mariscal nieto': 'Mariscal Nieto',
        'ilo': 'Ilo',
        'general sanchez cerro': 'General Sanchez Cerro'
    }
    return province_map.get(province.lower(), province.title())


def clean_whitespace(text: str) -> str:
    """
    Limpia espacios en blanco multiples y extremos.
    
    Args:
        text: Texto a limpiar
        
    Returns:
        Texto limpio sin espacios extras
        
    Example:
        >>> clean_whitespace('  Hola   mundo  ')
        'Hola mundo'
    """
    return ' '.join(text.split())
