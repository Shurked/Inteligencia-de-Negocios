"""
Utilidades para manejo de fechas, trimestres y meses.
"""

from datetime import datetime, timedelta
from typing import List, Tuple
import pandas as pd


def generate_quarters(start_year: int, end_year: int) -> List[Tuple[int, str]]:
    """
    Genera lista de (año, trimestre) entre años dados.
    
    Args:
        start_year: Año inicial
        end_year: Año final
        
    Returns:
        Lista de tuplas (año, 'Q1'|'Q2'|'Q3'|'Q4')
        
    Example:
        >>> generate_quarters(2022, 2023)
        [(2022, 'Q1'), (2022, 'Q2'), ..., (2023, 'Q4')]
    """
    quarters = []
    for year in range(start_year, end_year + 1):
        for q in ['Q1', 'Q2', 'Q3', 'Q4']:
            if year == end_year and q in ['Q2', 'Q3', 'Q4']:
                continue  # Solo hasta Q1 2025
            quarters.append((year, q))
    return quarters


def quarter_to_month_start(year: int, quarter: str) -> datetime:
    """
    Convierte año-trimestre a fecha de inicio del trimestre.
    
    Args:
        year: Año
        quarter: Trimestre ('Q1', 'Q2', 'Q3', 'Q4')
        
    Returns:
        datetime del primer día del trimestre
        
    Example:
        >>> quarter_to_month_start(2023, 'Q2')
        datetime(2023, 4, 1)
    """
    q_to_month = {'Q1': 1, 'Q2': 4, 'Q3': 7, 'Q4': 10}
    return datetime(year, q_to_month[quarter], 1)


def quarter_to_months(quarter: str) -> List[str]:
    """
    Convierte trimestre a lista de nombres de meses.
    
    Args:
        quarter: Trimestre ('Q1', 'Q2', 'Q3', 'Q4')
        
    Returns:
        Lista de nombres de meses en español
        
    Example:
        >>> quarter_to_months('Q1')
        ['Enero', 'Febrero', 'Marzo']
    """
    q_to_months = {
        'Q1': ['Enero', 'Febrero', 'Marzo'],
        'Q2': ['Abril', 'Mayo', 'Junio'],
        'Q3': ['Julio', 'Agosto', 'Septiembre'],
        'Q4': ['Octubre', 'Noviembre', 'Diciembre']
    }
    return q_to_months[quarter]


def validate_date_range(year: int, valid_range: Tuple[int, int] = (2022, 2025)) -> bool:
    """
    Valida que el año esté en el rango permitido.
    
    Args:
        year: Año a validar
        valid_range: Tupla (año_min, año_max)
        
    Returns:
        True si el año está en el rango, False en caso contrario
        
    Example:
        >>> validate_date_range(2023)
        True
        >>> validate_date_range(2026)
        False
    """
    return valid_range[0] <= year <= valid_range[1]


def get_month_number(month_name: str) -> int:
    """
    Convierte nombre de mes en español a número.
    
    Args:
        month_name: Nombre del mes en español
        
    Returns:
        Número del mes (1-12)
        
    Example:
        >>> get_month_number('Enero')
        1
    """
    months = {
        'Enero': 1, 'Febrero': 2, 'Marzo': 3, 'Abril': 4,
        'Mayo': 5, 'Junio': 6, 'Julio': 7, 'Agosto': 8,
        'Septiembre': 9, 'Octubre': 10, 'Noviembre': 11, 'Diciembre': 12
    }
    return months.get(month_name, 0)
