"""
Utilidades para validacion de datos.
"""

from typing import Any, Tuple, List
import pandas as pd


def validate_range(value: float, min_val: float, max_val: float, 
                   field_name: str = "Campo") -> Tuple[bool, str]:
    """
    Valida que un valor este dentro de un rango.
    
    Args:
        value: Valor a validar
        min_val: Valor minimo permitido
        max_val: Valor maximo permitido
        field_name: Nombre del campo para mensajes de error
    
    Returns:
        Tupla (is_valid, error_message)
        
    Example:
        >>> validate_range(50.0, 0.0, 100.0, "Porcentaje")
        (True, '')
        >>> validate_range(150.0, 0.0, 100.0, "Porcentaje")
        (False, 'Porcentaje: 150.0 fuera de rango [0.0, 100.0]')
    """
    if pd.isna(value):
        return False, f"{field_name}: valor nulo"
    
    if value < min_val or value > max_val:
        return False, f"{field_name}: {value} fuera de rango [{min_val}, {max_val}]"
    
    return True, ""


def validate_not_null(value: Any, field_name: str = "Campo") -> Tuple[bool, str]:
    """
    Valida que un valor no sea nulo.
    
    Args:
        value: Valor a validar
        field_name: Nombre del campo para mensajes de error
    
    Returns:
        Tupla (is_valid, error_message)
        
    Example:
        >>> validate_not_null(100, "Produccion")
        (True, '')
        >>> validate_not_null(None, "Produccion")
        (False, 'Produccion: valor nulo no permitido')
    """
    if pd.isna(value) or value is None:
        return False, f"{field_name}: valor nulo no permitido"
    return True, ""


def validate_percentage(value: float, field_name: str = "Campo") -> Tuple[bool, str]:
    """
    Valida que un porcentaje este entre 0 y 100.
    
    Args:
        value: Valor del porcentaje
        field_name: Nombre del campo para mensajes de error
    
    Returns:
        Tupla (is_valid, error_message)
        
    Example:
        >>> validate_percentage(75.5, "Utilizacion")
        (True, '')
    """
    return validate_range(value, 0.0, 100.0, field_name)


def validate_coordinates(lat: float, lon: float) -> Tuple[bool, str]:
    """
    Valida coordenadas geograficas para Peru.
    
    Args:
        lat: Latitud
        lon: Longitud
    
    Returns:
        Tupla (is_valid, error_message)
        
    Example:
        >>> validate_coordinates(-17.2544, -70.5844)
        (True, '')
    """
    # Peru: lat entre -18.5 y -0.5 (aprox), lon entre -82 y -68
    lat_valid, lat_msg = validate_range(lat, -18.5, -0.5, "Latitud")
    if not lat_valid:
        return False, lat_msg
    
    lon_valid, lon_msg = validate_range(lon, -82.0, -68.0, "Longitud")
    if not lon_valid:
        return False, lon_msg
    
    return True, ""


def validate_sum(values: List[float], expected_sum: float, 
                 tolerance: float = 0.01, field_name: str = "Suma") -> Tuple[bool, str]:
    """
    Valida que la suma de valores coincida con un valor esperado (con tolerancia).
    
    Args:
        values: Lista de valores a sumar
        expected_sum: Suma esperada
        tolerance: Tolerancia como porcentaje (0.01 = 1%)
        field_name: Nombre del campo para mensajes de error
    
    Returns:
        Tupla (is_valid, error_message)
        
    Example:
        >>> validate_sum([25.0, 25.0, 50.0], 100.0, 0.01, "Distribucion")
        (True, '')
    """
    actual_sum = sum(values)
    diff = abs(actual_sum - expected_sum)
    
    if diff > tolerance * expected_sum:
        return False, f"{field_name}: suma {actual_sum:.2f} difiere de esperado {expected_sum:.2f} (tolerancia {tolerance*100}%)"
    
    return True, ""


def validate_positive(value: float, field_name: str = "Campo") -> Tuple[bool, str]:
    """
    Valida que un valor sea positivo (mayor que 0).
    
    Args:
        value: Valor a validar
        field_name: Nombre del campo para mensajes de error
    
    Returns:
        Tupla (is_valid, error_message)
    """
    if pd.isna(value):
        return False, f"{field_name}: valor nulo"
    
    if value <= 0:
        return False, f"{field_name}: {value} debe ser mayor que 0"
    
    return True, ""


def validate_formula(actual: float, expected: float, tolerance: float = 0.01,
                     formula_name: str = "Formula") -> Tuple[bool, str]:
    """
    Valida que un calculo cumpla con una formula (con tolerancia).
    
    Args:
        actual: Valor actual calculado
        expected: Valor esperado segun formula
        tolerance: Tolerancia como porcentaje (0.01 = 1%)
        formula_name: Nombre de la formula para mensajes de error
    
    Returns:
        Tupla (is_valid, error_message)
        
    Example:
        >>> validate_formula(50.0, 50.5, 0.01, "Canon = 50% IR")
        (True, '')
    """
    if pd.isna(actual) or pd.isna(expected):
        return False, f"{formula_name}: valores nulos en validacion"
    
    diff = abs(actual - expected)
    
    if expected == 0:
        if actual == 0:
            return True, ""
        else:
            return False, f"{formula_name}: actual {actual:.2f} != esperado {expected:.2f}"
    
    if diff > tolerance * abs(expected):
        return False, f"{formula_name}: actual {actual:.2f} difiere de esperado {expected:.2f} (tolerancia {tolerance*100}%)"
    
    return True, ""
