"""
Configuracion del sistema de logging usando loguru.
"""

from loguru import logger
import sys
from datetime import datetime
import os

def setup_logging(log_level="INFO"):
    """
    Configura el sistema de logging con loguru.
    
    Args:
        log_level: Nivel de logging (DEBUG, INFO, WARNING, ERROR, CRITICAL)
    """
    # Remover handler por defecto
    logger.remove()
    
    # Console handler
    logger.add(
        sys.stdout,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {module}:{function}:{line} | {message}",
        level=log_level,
        colorize=True
    )
    
    # File handler - log general
    log_file = os.path.join('logs', f'etl_{datetime.now().strftime("%Y%m%d_%H%M%S")}.log')
    logger.add(
        log_file,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {module}:{function}:{line} | {message}",
        level="DEBUG",
        rotation="10 MB"
    )
    
    # File handler - solo errores
    error_log = os.path.join('logs', 'errors.log')
    logger.add(
        error_log,
        format="{time:YYYY-MM-DD HH:mm:ss} | {level: <8} | {module}:{function}:{line} | {message}",
        level="ERROR",
        rotation="5 MB"
    )
    
    logger.info("Sistema de logging inicializado")
    return logger
