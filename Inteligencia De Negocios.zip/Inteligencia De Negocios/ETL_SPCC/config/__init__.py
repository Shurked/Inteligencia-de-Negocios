"""
Modulo de configuracion del proyecto ETL.
"""

from . import settings
from . import logging_config

__all__ = ['settings', 'logging_config']
