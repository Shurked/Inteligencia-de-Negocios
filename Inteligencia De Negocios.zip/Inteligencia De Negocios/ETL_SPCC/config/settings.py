"""
Configuracion general del proyecto ETL - Southern Peru Copper Corporation
Contiene constantes, parametros fiscales y rutas del proyecto.
"""

import os

# Constantes del proyecto
AÑOS = [2022, 2023, 2024, 2025]
TRIMESTRES = ['Q1', 'Q2', 'Q3', 'Q4']
MESES = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio',
         'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre']

# Unidades operativas
UNIDADES_SPCC = ['Toquepala', 'Cuajone', 'Fundicion Ilo']

# Ubicaciones
COORDENADAS = {
    'Toquepala': {'lat': -17.2544, 'lon': -70.5844, 'dept': 'Tacna'},
    'Cuajone': {'lat': -16.9842, 'lon': -70.7654, 'dept': 'Moquegua'},
    'Fundicion Ilo': {'lat': -17.6386, 'lon': -71.3375, 'dept': 'Moquegua'}
}

# Parametros fiscales
TASA_IR = 0.295
TASA_CANON = 0.50
TASA_REGALIAS_PROMEDIO = 0.051

# Distribucion Canon
DIST_CANON = {
    'Municipal Distrito': 0.10,
    'Municipal Provincia': 0.25,
    'Municipal Departamento': 0.40,
    'Regional': 0.20,
    'Universitario': 0.05
}

# Distribucion Regalias
DIST_REGALIAS = {
    'Municipal Distrito': 0.20,
    'Municipal Provincia': 0.20,
    'Municipal Departamento': 0.40,
    'Regional': 0.15,
    'Universitario': 0.05
}

# Rangos de validacion
PRECIO_COBRE_MIN = 2.0
PRECIO_COBRE_MAX = 6.0
UTILIZACION_MIN = 80.0
UTILIZACION_MAX = 105.0

# Rutas
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA_RAW_DIR = os.path.join(BASE_DIR, 'data', 'raw')
DATA_INTERMEDIATE_DIR = os.path.join(BASE_DIR, 'data', 'intermediate')
DATA_OUTPUT_DIR = os.path.join(BASE_DIR, 'data', 'output')
LOGS_DIR = os.path.join(BASE_DIR, 'logs')
